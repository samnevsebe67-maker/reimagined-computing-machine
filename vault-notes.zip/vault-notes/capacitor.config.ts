import type { CapacitorConfig } from '@capacitor/cli';
const config: CapacitorConfig = {
  appId: 'com.vaultnotes.app', appName: 'Vault Notes', webDir: 'dist',
  server: { androidScheme: 'https' }, // secure context => crypto.subtle работает
  android: { allowMixedContent: false }
};
export default config;
