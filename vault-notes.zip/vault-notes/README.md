# Vault Notes
Web: `npm install && npm run dev`

## Android APK
Локально (нужны JDK 17 + Android Studio/SDK):
    npm install && npm run build
    npx cap add android && npx cap sync android
    cd android && ./gradlew assembleDebug   # android/app/build/outputs/apk/debug/app-debug.apk
Без SDK: залейте проект в GitHub -> Actions -> "Build APK" -> скачайте артефакт.
В APK: блокировка при сворачивании, запрет скриншотов (FLAG_SECURE), отключён Android Backup.
