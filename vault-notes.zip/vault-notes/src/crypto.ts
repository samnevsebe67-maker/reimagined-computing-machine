// Только стандартный Web Crypto: PBKDF2-SHA256 -> AES-256-GCM. Пароль нигде не сохраняется.
export const ITERATIONS = 600_000;
export interface EncryptedRecord { version: 1; iv: string; ciphertext: string } // ciphertext включает 16-байтный GCM auth tag
const enc = new TextEncoder(), dec = new TextDecoder();
export const toB64 = (b: Uint8Array) => { let s = ''; for (const x of b) s += String.fromCharCode(x); return btoa(s); };
export const fromB64 = (s: string) => Uint8Array.from(atob(s), c => c.charCodeAt(0));
export const randomBytes = (n: number) => crypto.getRandomValues(new Uint8Array(n));
export async function deriveKey(password: string, salt: Uint8Array, iterations = ITERATIONS): Promise<CryptoKey> {
  const base = await crypto.subtle.importKey('raw', enc.encode(password), 'PBKDF2', false, ['deriveKey']);
  return crypto.subtle.deriveKey({ name: 'PBKDF2', hash: 'SHA-256', salt, iterations }, base,
    { name: 'AES-GCM', length: 256 }, false, ['encrypt', 'decrypt']); // non-extractable
}
export async function encryptJson(key: CryptoKey, data: unknown): Promise<EncryptedRecord> {
  const iv = randomBytes(12); // новый IV на каждое шифрование
  const ct = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, enc.encode(JSON.stringify(data)));
  return { version: 1, iv: toB64(iv), ciphertext: toB64(new Uint8Array(ct)) };
}
export async function decryptJson<T>(key: CryptoKey, r: EncryptedRecord): Promise<T> {
  const pt = await crypto.subtle.decrypt({ name: 'AES-GCM', iv: fromB64(r.iv) }, key, fromB64(r.ciphertext));
  return JSON.parse(dec.decode(pt));
}
export function strength(p: string): { score: number; label: string } {
  let s = 0; if (p.length >= 12) s++; if (p.length >= 16) s++; if (/[a-zа-я]/.test(p) && /[A-ZА-Я]/.test(p)) s++;
  if (/\d/.test(p)) s++; if (/[^\w\s]/.test(p)) s++; if (/(.)\1{2,}/.test(p) || p.length < 8) s = Math.max(0, s - 2);
  return { score: s, label: ['Очень слабый', 'Слабый', 'Средний', 'Хороший', 'Сильный', 'Отличный'][s] };
}
