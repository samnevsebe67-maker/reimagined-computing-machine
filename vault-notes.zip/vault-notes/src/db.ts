import type { EncryptedRecord } from './crypto';
export interface Meta { salt: string; iterations: number; verifier: EncryptedRecord; settings?: EncryptedRecord }
const open = () => new Promise<IDBDatabase>((res, rej) => {
  const r = indexedDB.open('vault-notes', 1);
  r.onupgradeneeded = () => { r.result.createObjectStore('meta'); r.result.createObjectStore('notes'); };
  r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
});
const run = async <T,>(store: string, mode: IDBTransactionMode, f: (s: IDBObjectStore) => IDBRequest<T>) => {
  const db = await open();
  return new Promise<T>((res, rej) => { const q = f(db.transaction(store, mode).objectStore(store)); q.onsuccess = () => res(q.result); q.onerror = () => rej(q.error); });
};
export const getMeta = () => run<Meta | undefined>('meta', 'readonly', s => s.get('main'));
export const putMeta = (m: Meta) => run('meta', 'readwrite', s => s.put(m, 'main'));
export const putNote = (id: string, r: EncryptedRecord) => run('notes', 'readwrite', s => s.put(r, id));
export const delNote = (id: string) => run('notes', 'readwrite', s => s.delete(id));
export async function allNotes(): Promise<[string, EncryptedRecord][]> {
  const [k, v] = await Promise.all([run<IDBValidKey[]>('notes', 'readonly', s => s.getAllKeys()), run<EncryptedRecord[]>('notes', 'readonly', s => s.getAll())]);
  return k.map((x, i) => [String(x), v[i]]);
}
export async function wipe() { await run('notes', 'readwrite', s => s.clear()); await run('meta', 'readwrite', s => s.clear()); }
