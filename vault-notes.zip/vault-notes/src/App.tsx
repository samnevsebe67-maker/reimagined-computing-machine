import { useCallback, useEffect, useRef, useState } from 'react';
import { ITERATIONS, deriveKey, decryptJson, encryptJson, randomBytes, fromB64, toB64, strength } from './crypto';
import { allNotes, delNote, getMeta, putMeta, putNote, wipe, type Meta } from './db';

interface Note { id: string; title: string; body: string; tags: string[]; updated: number }
interface Settings { lockMinutes: number } // 0 = никогда
const OPTIONS = [[1, '1 минута'], [5, '5 минут'], [15, '15 минут'], [30, '30 минут'], [0, 'Никогда']] as const;
const card = 'w-full max-w-sm rounded-2xl border border-emerald-400/20 bg-[#121821] p-6 shadow-2xl';
const input = 'w-full rounded-lg bg-[#0b0f14] border border-white/10 px-3 py-2 text-slate-100 outline-none focus:border-emerald-400';
const btn = 'rounded-lg bg-emerald-400 px-4 py-2 font-semibold text-black disabled:opacity-40';

function Shell({ children }: { children: React.ReactNode }) {
  return <div className="min-h-screen grid place-items-center p-4 text-slate-200">{children}</div>;
}

export default function App() {
  const [phase, setPhase] = useState<'loading' | 'setup' | 'locked' | 'open'>('loading');
  const [meta, setMeta] = useState<Meta>();
  const keyRef = useRef<CryptoKey | null>(null); // ключ только в памяти
  const [notes, setNotes] = useState<Note[]>([]);
  const [settings, setSettings] = useState<Settings>({ lockMinutes: 5 });

  useEffect(() => { getMeta().then(m => { setMeta(m); setPhase(m ? 'locked' : 'setup'); }); }, []);

  const lock = useCallback(() => { keyRef.current = null; setNotes([]); setPhase('locked'); }, []);

  async function unlockWith(key: CryptoKey, m: Meta) {
    keyRef.current = key;
    setSettings(m.settings ? await decryptJson<Settings>(key, m.settings) : { lockMinutes: 5 });
    const rows = await allNotes();
    setNotes(await Promise.all(rows.map(async ([id, r]) => ({ ...(await decryptJson<Omit<Note, 'id'>>(key, r)), id }))));
    setPhase('open');
  }

  if (phase === 'loading') return null;
  if (phase === 'setup') return <Setup onDone={async (pw) => {
    const salt = randomBytes(16), key = await deriveKey(pw, salt);
    const m: Meta = { salt: toB64(salt), iterations: ITERATIONS, verifier: await encryptJson(key, { ok: 'vault' }) };
    m.settings = await encryptJson(key, { lockMinutes: 5 });
    await putMeta(m); setMeta(m); await unlockWith(key, m);
  }} />;
  if (phase === 'locked') return <LockScreen meta={meta!} onUnlock={unlockWith} onWipe={async () => { await wipe(); setMeta(undefined); setPhase('setup'); }} />;
  return <Vault notes={notes} setNotes={setNotes} settings={settings} lock={lock}
    saveSettings={async s => { setSettings(s); const m = { ...meta!, settings: await encryptJson(keyRef.current!, s) }; await putMeta(m); setMeta(m); }}
    save={async n => { await putNote(n.id, await encryptJson(keyRef.current!, { title: n.title, body: n.body, tags: n.tags, updated: n.updated })); }} />;
}

function Setup({ onDone }: { onDone: (pw: string) => Promise<void> }) {
  const [a, setA] = useState(''), [b, setB] = useState(''), [busy, setBusy] = useState(false);
  const s = strength(a), ok = a.length >= 10 && a === b && s.score >= 2;
  return <Shell><div className={card}>
    <h1 className="text-2xl font-bold text-emerald-400">🔐 Vault Notes</h1>
    <p className="mt-1 text-sm text-slate-400">Создайте Master Password. Данные шифруются и остаются на этом устройстве.</p>
    <div className="mt-4 space-y-3">
      <input className={input} type="password" placeholder="Master Password" value={a} onChange={e => setA(e.target.value)} autoComplete="new-password" />
      <div className="h-1.5 rounded bg-white/10"><div className="h-full rounded bg-emerald-400 transition-all" style={{ width: `${(s.score / 5) * 100}%` }} /></div>
      <div className="text-xs text-slate-400">Сложность: {a ? s.label : '—'} (минимум 10 символов)</div>
      <input className={input} type="password" placeholder="Повторите пароль" value={b} onChange={e => setB(e.target.value)} autoComplete="new-password" />
      {b && a !== b && <div className="text-xs text-red-400">Пароли не совпадают</div>}
    </div>
    <p className="mt-4 rounded-lg bg-amber-400/10 p-3 text-sm text-amber-300">Если вы забудете пароль, восстановить зашифрованные заметки будет невозможно.</p>
    <button className={btn + ' mt-4 w-full'} disabled={!ok || busy} onClick={async () => { setBusy(true); await onDone(a); }}>{busy ? 'Создаём ключ…' : 'Создать хранилище'}</button>
  </div></Shell>;
}

function LockScreen({ meta, onUnlock, onWipe }: { meta: Meta; onUnlock: (k: CryptoKey, m: Meta) => Promise<void>; onWipe: () => void }) {
  const [pw, setPw] = useState(''), [err, setErr] = useState(''), [busy, setBusy] = useState(false);
  async function go() {
    setBusy(true); setErr('');
    try { const k = await deriveKey(pw, fromB64(meta.salt), meta.iterations); await decryptJson(k, meta.verifier); setPw(''); await onUnlock(k, meta); }
    catch { setErr('Неверный пароль'); setBusy(false); }
  }
  return <Shell><div className={card}>
    <div className="text-4xl">🔒</div><h1 className="mt-2 text-xl font-bold">Хранилище заблокировано</h1>
    <input className={input + ' mt-4'} type="password" autoFocus placeholder="Master Password" value={pw} onChange={e => setPw(e.target.value)} onKeyDown={e => e.key === 'Enter' && pw && go()} autoComplete="current-password" />
    {err && <div className="mt-2 text-sm text-red-400">{err}</div>}
    <button className={btn + ' mt-4 w-full'} disabled={!pw || busy} onClick={go}>{busy ? 'Проверяем…' : 'Разблокировать'}</button>
    <button className="mt-6 text-xs text-slate-500 underline" onClick={() => confirm('Все заметки будут удалены безвозвратно. Продолжить?') && onWipe()}>Забыли пароль? Стереть хранилище</button>
  </div></Shell>;
}

function Vault({ notes, setNotes, settings, saveSettings, lock, save }: {
  notes: Note[]; setNotes: React.Dispatch<React.SetStateAction<Note[]>>; settings: Settings;
  saveSettings: (s: Settings) => Promise<void>; lock: () => void; save: (n: Note) => Promise<void>;
}) {
  const [sel, setSel] = useState<string>(), [q, setQ] = useState(''), [showSet, setShowSet] = useState(false);
  const timer = useRef<number>();
  useEffect(() => { // автоблокировка по неактивности
    if (!settings.lockMinutes) return;
    const reset = () => { clearTimeout(timer.current); timer.current = window.setTimeout(lock, settings.lockMinutes * 60_000); };
    const ev = ['pointerdown', 'keydown', 'mousemove', 'touchstart', 'scroll'];
    ev.forEach(e => addEventListener(e, reset, { passive: true })); reset();
    return () => { ev.forEach(e => removeEventListener(e, reset)); clearTimeout(timer.current); };
  }, [settings.lockMinutes, lock]);

  useEffect(() => { // в APK: блокировка при сворачивании приложения
    const native = !!(window as any).Capacitor?.isNativePlatform?.();
    if (!native) return;
    const h = () => { if (document.hidden) lock(); };
    document.addEventListener('visibilitychange', h);
    return () => document.removeEventListener('visibilitychange', h);
  }, [lock]);

  const cur = notes.find(n => n.id === sel);
  const add = async () => { const n: Note = { id: crypto.randomUUID(), title: 'Новая заметка', body: '', tags: [], updated: Date.now() }; setNotes(p => [n, ...p]); setSel(n.id); await save(n); };
  const edit = (patch: Partial<Note>) => { const n = { ...cur!, ...patch, updated: Date.now() }; setNotes(p => p.map(x => x.id === n.id ? n : x)); void save(n); };
  const del = async () => { if (!cur || !confirm('Удалить заметку?')) return; await delNote(cur.id); setNotes(p => p.filter(x => x.id !== cur.id)); setSel(undefined); };
  const list = notes.filter(n => (n.title + n.body + n.tags.join(' ')).toLowerCase().includes(q.toLowerCase())).sort((a, b) => b.updated - a.updated);

  return <div className="flex h-screen flex-col text-slate-200 md:flex-row">
    <aside className={`${sel ? 'hidden md:flex' : 'flex'} w-full flex-col border-r border-white/10 bg-[#121821] md:w-80`}>
      <div className="flex items-center gap-2 p-3">
        <span className="font-bold text-emerald-400">🔐 Vault</span>
        <button className="ml-auto text-sm" onClick={() => setShowSet(s => !s)}>⚙️</button>
        <button className="rounded bg-red-500/20 px-2 py-1 text-sm text-red-300" onClick={lock}>Заблокировать сейчас</button>
      </div>
      {showSet && <div className="mx-3 mb-2 rounded-lg bg-black/30 p-3 text-sm">Автоблокировка
        <select className={input + ' mt-1'} value={settings.lockMinutes} onChange={e => saveSettings({ lockMinutes: +e.target.value })}>
          {OPTIONS.map(([v, l]) => <option key={v} value={v}>{l}</option>)}</select></div>}
      <div className="flex gap-2 px-3"><input className={input} placeholder="Поиск…" value={q} onChange={e => setQ(e.target.value)} /><button className={btn} onClick={add}>＋</button></div>
      <ul className="mt-2 flex-1 overflow-auto">{list.map(n => <li key={n.id}>
        <button onClick={() => setSel(n.id)} className={`w-full px-4 py-3 text-left hover:bg-white/5 ${n.id === sel ? 'bg-white/10' : ''}`}>
          <div className="truncate font-medium">{n.title || 'Без названия'}</div>
          <div className="truncate text-xs text-slate-500">{n.tags.map(t => '#' + t).join(' ') || n.body.slice(0, 40)}</div></button></li>)}
        {!list.length && <li className="p-4 text-sm text-slate-500">Заметок нет</li>}</ul>
    </aside>
    <main className={`${sel ? 'flex' : 'hidden md:flex'} flex-1 flex-col bg-[#0b0f14] p-4`}>
      {cur ? <>
        <div className="flex items-center gap-2"><button className="md:hidden" onClick={() => setSel(undefined)}>←</button>
          <input className="flex-1 bg-transparent text-2xl font-bold outline-none" value={cur.title} onChange={e => edit({ title: e.target.value })} />
          <button className="text-red-400" onClick={del}>🗑</button></div>
        <input className="mt-2 bg-transparent text-sm text-emerald-300 outline-none" placeholder="теги через запятую" defaultValue={cur.tags.join(', ')} key={cur.id}
          onChange={e => edit({ tags: e.target.value.split(',').map(t => t.trim()).filter(Boolean) })} />
        <textarea className="mt-3 flex-1 resize-none bg-transparent leading-relaxed outline-none" placeholder="Пишите здесь…" value={cur.body} onChange={e => edit({ body: e.target.value })} />
      </> : <div className="m-auto text-slate-600">Выберите или создайте заметку</div>}
    </main>
  </div>;
}
